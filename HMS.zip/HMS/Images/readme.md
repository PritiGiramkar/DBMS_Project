this folder contains all images that are used in the project.
